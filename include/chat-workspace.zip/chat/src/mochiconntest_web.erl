-module(mochiconntest_web).
-author('author <author@example.com>').
-export([start/1, stop/0, loop/2]).
-export([get_time/0, get2/0]).
-define(TIMEOUT, 20000).

start(Options) ->
    {DocRoot, Options1} = get_option(docroot, Options),
    Loop = fun (Req) ->
                   ?MODULE:loop(Req, DocRoot)
           end,
    mochiweb_http:start([{max, 1000000}, {name, ?MODULE}, {loop, Loop} | Options1]).

stop() ->
    mochiweb_http:stop(?MODULE).

loop(Req, DocRoot) ->
    "/" ++ Path = Req:get(path),
    case Req:get(method) of
        Method when Method =:= 'GET'; Method =:= 'HEAD' ->
            case Path of
                "test/" ++ Id ->
					Response = Req:ok({"text/html; charset=utf-8", [{"server", "Mochiweb-Test"}], chunked}),
					Response:write_chunk("<div>Mochiconntest welcome you! You id: " ++ Id ++ "</div>\n"),
					feed(Response, Id, 1);
				"redi" ->
					Target = "http://www.baidu.com/",
					Req:respond({302, [{"Location", Target}], "Redirecting to " ++ Target});
                _ ->
                    Req:not_found()
            end;
        _ ->
            Req:respond({501, [], []})
    end.


feed(Response, Path, N) ->
	receive
		%% to do nothing 
	after 10000 ->
		%% get_time() 返回 List， 需要设置 ~s,若使用~p/~w则被“”包含
		Msg = io_lib:format("<div>Chunk ~w for id ~s @ ~s</div>\n", [N, Path, get_time()]),
		Response:write_chunk(Msg)
	end,
	
	if N < 3 ->
		   feed(Response, Path, N+1);
	   true ->
		   Bye = io_lib:format("<div><strong>Done @ ~s!</strong></div>\n", [get_time()]),
		   Response:write_chunk(Bye),
		   %% 发送空数据，然后结束
		   Response:write_chunk([])
	   end.

get_time() ->
	{{Year, Month, Day}, {Hour, Minute, Second}} = erlang:localtime(),
	lists:flatten(
	  io_lib:format("~p-~2..0w-~2..0w ~2..0w:~2..0w:~2..0w", [Year, Month, Day, Hour, Minute, Second])
	).

get2() ->
	Msg = io_lib:format("<div><strong>Done @ ~s!</strong></div>\n", [get_time()]),
	io:format(Msg),
	Msg2 = [],
	Len = iolist_size(Msg2),
	io:format("Len is ~p~n", [Len]),
	ok.

%% Internal API

get_option(Option, Options) ->
    {proplists:get_value(Option, Options), proplists:delete(Option, Options)}.